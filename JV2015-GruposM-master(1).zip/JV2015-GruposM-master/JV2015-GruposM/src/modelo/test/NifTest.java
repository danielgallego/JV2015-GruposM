package modelo.test;

import static org.junit.Assert.*;

import org.junit.Test;

public class NifTest {

	@Test
	public void testNifString() {
		fail("Not yet implemented");
	}

	@Test
	public void testNif() {
		fail("Not yet implemented");
	}

	@Test
	public void testNifNif() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetTexto() {
		fail("Not yet implemented");
	}

	@Test
	public void testSetTexto() {
		fail("Not yet implemented");
	}

	@Test
	public void testToString() {
		fail("Not yet implemented");
	}

}
